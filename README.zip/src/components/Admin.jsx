import React from 'react'
import AdminNav from './AdminNav'
import AdminAddProduct from '../pages/AdminAddProduct'
import AdminLayout from './AdminLayout'

const Admin = () => {
  return (
    <div>
        <AdminLayout/>
       
        {/* <AdminAddProduct/> */}
    </div>
  )
}


export default Admin