import React from 'react'

const Footer = () => {
  return (
    <div className='bg-gray-800 flex flex-col items-center justify-center w-full h-[300px] text-white '>
        <p>        This is a simple Footer.
</p>
<p>A simple footer with few minor details</p>

    </div>
  )
}


export default Footer